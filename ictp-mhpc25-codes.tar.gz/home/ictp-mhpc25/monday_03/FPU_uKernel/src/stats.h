#include <stddef.h>
#include <stdlib.h>

double sum(double *v, size_t elem);
double max(double *v, size_t elem);
double min(double *v, size_t elem);
double std(double *v, size_t elem);
