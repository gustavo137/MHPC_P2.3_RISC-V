
#ifndef NITERS
  #define NITERS (unsigned long long)1e4
#endif

extern const unsigned long long NINSTR;
extern const unsigned long long NFPOPS;

double *gflops_global;

void work();
