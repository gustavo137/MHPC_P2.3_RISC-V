#pragma once

#define REPEAT10(_x) \
  _x _x _x _x _x _x _x _x _x _x
